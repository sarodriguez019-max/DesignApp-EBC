//Array(Arreglo) para las imagenes, aquí van a poner las imagenes//
// de cada uno ( ES INDIVIDUAL) //

//fotos de Unsplash (ajustadas con w=400&h=300&fit=crop)//

const imagenes = [
  "https://images.pexels.com/photos/1108099/pexels-photo-1108099.jpeg",
  
  "https://images.pexels.com/photos/69371/pexels-photo-69371.jpeg",
  
  "https://images.pexels.com/photos/406014/pexels-photo-406014.jpeg",
  
  "https://images.pexels.com/photos/2607544/pexels-photo-2607544.jpeg",
  
 "https://images.pexels.com/photos/160846/french-bulldog-summer-smile-joy-160846.jpeg",
  
  "https://images.pexels.com/photos/58997/pexels-photo-58997.jpeg"
];

//Seleccion de elementos // 

const boton = document.getElementById("btn-cambiar");
const imagenCard = document.getElementById("card-img");
const textoCard = document.getElementById("card-text");

//contador de las imagenes//

let indice = 0;

//evento del click//
boton.addEventListener("click", () => {
 
 //lo siguiente es para que avance la foto //
  indice++;

//el siguiente if es para que cuando llegue al final se regrese al inicio//
  
  if (indice >= imagenes.length) {
    indice = 0;
  }
      // Cambiar imagen y texto //
imagenCard.src = imagenes[indice];
  textoCard.textContent = `Mostrando imagen ${indice + 1} de ${imagenes.length}`;
});