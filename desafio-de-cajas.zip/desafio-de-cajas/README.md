# Desafio de cajas

A Pen created on CodePen.

Original URL: [https://codepen.io/SANTIAGO-ALFREDO-RODRIGUEZGUTIERREZ/pen/YPygJLQ](https://codepen.io/SANTIAGO-ALFREDO-RODRIGUEZGUTIERREZ/pen/YPygJLQ).

